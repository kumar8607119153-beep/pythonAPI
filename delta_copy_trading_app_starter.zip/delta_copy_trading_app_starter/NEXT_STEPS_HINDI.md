# अब इस प्रोजेक्ट पर आगे क्या करना है

1. ZIP को कंप्यूटर पर निकालें।
2. Backend चलाकर `/health` और `/docs` जाँचें।
3. Android Studio में `android` फ़ोल्डर खोलें और emulator पर शुरुआती स्क्रीन चलाएँ।
4. उसके बाद OTP provider और सुरक्षित Owner login जोड़ना होगा।
5. फिर Delta API के read-only endpoints जोड़कर वास्तविक सदस्य डेटा दिखाएँ।
6. सबसे अंत में सदस्य के लिए अलग order executor, dry-run tests और सुरक्षा जाँच होंगी।

यह अभी शुरुआती source project है, production APK नहीं। इस ZIP से अपने-आप live trading शुरू नहीं होगी।
