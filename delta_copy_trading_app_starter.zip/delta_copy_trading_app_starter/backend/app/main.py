from contextlib import asynccontextmanager
import os
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

DB_PATH = Path(os.getenv("DATABASE_PATH", "./copy_trading.db"))


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def connect_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with connect_db() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS members (
                member_id TEXT PRIMARY KEY,
                phone_e164 TEXT NOT NULL UNIQUE,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield


app = FastAPI(
    title="Delta Copy Trading API — Starter",
    version="0.1.0",
    description=(
        "Starter scaffold only. OTP, real Delta data, encrypted credentials, "
        "and live order execution are intentionally not configured."
    ),
    lifespan=lifespan,
)


class JoinRequest(BaseModel):
    phone_e164: str = Field(min_length=8, max_length=20, pattern=r"^\+[1-9][0-9]{7,14}$")


class OwnerAction(BaseModel):
    owner_token: str = Field(min_length=1, description="Placeholder token; replace with real owner auth")
    member_id: str = Field(min_length=1)


class StatusResponse(BaseModel):
    service: str
    otp_auth: str
    delta_account_data: str
    live_order_execution: str
    message: str


@app.get("/health", response_model=StatusResponse)
def health():
    return StatusResponse(
        service="OK",
        otp_auth="NOT_CONFIGURED",
        delta_account_data="NOT_CONFIGURED",
        live_order_execution="DISABLED",
        message="Starter mode only; no exchange orders are sent and no balances are fabricated.",
    )


@app.post("/members/join")
def request_join(body: JoinRequest):
    """Creates a pending request. Phone ownership is NOT verified until OTP is implemented."""
    member_id = str(uuid.uuid4())
    stamp = now_iso()
    try:
        with connect_db() as con:
            con.execute(
                "INSERT INTO members(member_id, phone_e164, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
                (member_id, body.phone_e164, "pending_otp_not_verified", stamp, stamp),
            )
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="इस मोबाइल नंबर की request पहले से मौजूद है")
    return {
        "member_id": member_id,
        "status": "pending_otp_not_verified",
        "message": "यह केवल development request है। OTP सत्यापन और Owner approval अभी configured नहीं हैं।",
    }


@app.get("/members")
def list_members(owner_token: str):
    """INSECURE placeholder: do not expose publicly until real owner authentication is implemented."""
    if owner_token != os.getenv("DEV_OWNER_TOKEN", "local-dev-only"):
        raise HTTPException(status_code=403, detail="Owner authentication failed")
    with connect_db() as con:
        rows = con.execute(
            "SELECT member_id, phone_e164, status, created_at, updated_at FROM members ORDER BY created_at DESC"
        ).fetchall()
    return {"members": [dict(row) for row in rows], "mode": "development_only"}


@app.post("/members/approve")
def approve_member(body: OwnerAction):
    """Development-only approval endpoint. Not safe for internet use."""
    if body.owner_token != os.getenv("DEV_OWNER_TOKEN", "local-dev-only"):
        raise HTTPException(status_code=403, detail="Owner authentication failed")
    with connect_db() as con:
        row = con.execute("SELECT member_id FROM members WHERE member_id=?", (body.member_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Member नहीं मिला")
        con.execute(
            "UPDATE members SET status='approved_dashboard_only', updated_at=? WHERE member_id=?",
            (now_iso(), body.member_id),
        )
    return {
        "member_id": body.member_id,
        "status": "approved_dashboard_only",
        "message": "सिर्फ development approval; इससे live trading शुरू नहीं होती।",
    }


@app.post("/members/remove")
def remove_member(body: OwnerAction):
    """Marks member removed; deliberately does not cancel exchange orders or close positions."""
    if body.owner_token != os.getenv("DEV_OWNER_TOKEN", "local-dev-only"):
        raise HTTPException(status_code=403, detail="Owner authentication failed")
    with connect_db() as con:
        row = con.execute("SELECT member_id FROM members WHERE member_id=?", (body.member_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Member नहीं मिला")
        con.execute(
            "UPDATE members SET status='removed_no_new_orders', updated_at=? WHERE member_id=?",
            (now_iso(), body.member_id),
        )
    return {
        "member_id": body.member_id,
        "status": "removed_no_new_orders",
        "exchange_orders": "UNCHANGED",
        "positions": "UNCHANGED",
        "message": "Development record updated. कोई live order या position बदली नहीं गई।",
    }


@app.get("/member/dashboard")
def member_dashboard(member_id: str):
    with connect_db() as con:
        row = con.execute(
            "SELECT member_id, status FROM members WHERE member_id=?", (member_id,)
        ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Member नहीं मिला")
    return {
        "member_id": row["member_id"],
        "member_status": row["status"],
        "data_status": "NOT_CONNECTED",
        "balance": None,
        "positions": None,
        "orders": None,
        "chart": None,
        "pnl": None,
        "message": "Delta API integration अभी configured नहीं है। नकली बैलेंस, चार्ट, ऑर्डर या P/L नहीं दिखाए जाएँगे।",
        "trading_controls": "READ_ONLY_MEMBER_UI",
    }
