# Backend starter
See `../README_HINDI.md` for Hindi setup steps.

This scaffold is intentionally non-trading. No endpoint sends exchange orders. The owner token and member endpoints are development placeholders and must not be exposed to the public internet.
