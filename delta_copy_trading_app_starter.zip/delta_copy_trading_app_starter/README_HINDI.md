# Delta Copy Trading — शुरुआती ऐप प्रोजेक्ट (Hindi)

यह **काम शुरू करने योग्य source scaffold** है, तैयार/प्रमाणित production trading app नहीं। इसमें Android ऐप का आधार और FastAPI backend का ढाँचा है। इसमें कोई वास्तविक ऑर्डर नहीं भेजा जाता और कोई नकली बैलेंस/P&L नहीं दिखाया जाता।

## इसमें क्या बनाया गया है
- Android Studio में खोलने योग्य Kotlin + Jetpack Compose ऐप का शुरुआती ढाँचा।
- FastAPI backend: health, join request, owner approval/removal और account-status के शुरुआती endpoints।
- सदस्य के ऐप को read-only रखने के लिए UI आधार।
- SQLite में सदस्य-request का शुरुआती रिकॉर्ड।
- सभी trading/data integrations को स्पष्ट रूप से `NOT_CONFIGURED` बताया जाता है; नकली डेटा नहीं लौटाया जाता।

## अभी क्या नहीं है
- OTP SMS provider integration नहीं।
- Delta API keys की encrypted storage और member-specific signed API client नहीं।
- Delta की live balance/orders/positions/ohlc integration नहीं।
- Owner strategy से signals लेने और प्रत्येक सदस्य के लिए orders execute करने वाला production worker नहीं।
- APK build/signing या live exchange tests नहीं हुए।

## पहले सुरक्षा
1. Delta API key/secret कभी ChatGPT, GitHub या इस ZIP में न डालें।
2. हर सदस्य के API key में केवल आवश्यक permissions दें: read + trade, withdrawal permission बंद रखें यदि Delta यह विकल्प देता हो।
3. API credentials को production में server-side encrypted secrets vault में रखें। इस scaffold में credentials स्वीकार/सहेजे नहीं जाते।
4. Live trading को तब तक चालू न करें जब तक per-account isolation, order ownership, duplicate-signal handling, reconnect/recovery और removal behavior की जाँच न हो।
5. सदस्य हटाने का तय व्यवहार: उस सदस्य के लिए नए orders रोकना; पहले से exchange पर मौजूद orders/positions अपने-आप cancel/close नहीं करना।

## Backend चलाने का तरीका
Python 3.11+:
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```
फिर `http://127.0.0.1:8000/docs` खोलें। यह केवल development/local testing के लिए है; सार्वजनिक इंटरनेट पर बिना authentication/security hardening के expose न करें।

## Android ऐप
Android Studio में `android/` फ़ोल्डर खोलें। Gradle sync करें और ऐप चलाएँ।
`ApiConfig.kt` में backend का URL सेट करें:
- Emulator: `http://10.0.2.2:8000/`
- असली फोन: उसी सुरक्षित स्थानीय नेटवर्क पर कंप्यूटर का LAN IP (उदाहरण केवल: `http://192.168.1.10:8000/`)।
HTTP cleartext केवल development के लिए सक्षम है। Production में HTTPS अनिवार्य करें।

## अगले विकास चरण
1. OTP provider + Owner role को सुरक्षित तरीके से जोड़ना।
2. encrypted per-member credential vault और member-specific Delta clients बनाना।
3. Owner के मौजूदा SuperTrend/Grid engine से confirmed signals का सुरक्षित interface बनाना।
4. पहले केवल read-only वास्तविक Delta account data जोड़ना।
5. sandbox/dry-run executor, फिर सीमित और स्पष्ट रूप से मंज़ूर live test।
6. tests पास होने पर signed APK बनाना।

**महत्वपूर्ण:** Owner का मोबाइल डैशबोर्ड खुला होना server uptime की गारंटी नहीं देता। Member apps बंद रहने पर भी trading के लिए backend worker को हमेशा चलने वाले server पर चलना होगा।
