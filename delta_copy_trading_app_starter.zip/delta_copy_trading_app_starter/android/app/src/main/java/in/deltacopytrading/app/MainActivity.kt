package in.deltacopytrading.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DeltaCopyApp() }
    }
}

@Composable
fun DeltaCopyApp() {
    var serverStatus by remember { mutableStateOf("जाँच नहीं हुई") }
    var serverMessage by remember { mutableStateOf("Backend से जुड़ने के लिए नीचे दबाएँ।") }
    var loading by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("DELTA COPY TRADING", style = MaterialTheme.typography.headlineSmall)
                Text("Member dashboard • Read-only starter", style = MaterialTheme.typography.titleMedium)
                Text("Owner सिग्नल नियंत्रित करेगा। सदस्य का ऐप बंद होने पर भी trading तभी जारी रह सकती है जब सुरक्षित server worker चल रहा हो।")

                HorizontalDivider()

                Text("Backend status", style = MaterialTheme.typography.titleMedium)
                Text(serverStatus)
                Text(serverMessage)

                Button(
                    enabled = !loading,
                    onClick = {
                        loading = true
                        serverStatus = "जाँच जारी…"
                        serverMessage = ""
                        // A lightweight background thread, no exchange requests.
                        Thread {
                            val result = try {
                                val conn = (URL(ApiConfig.BASE_URL + "health").openConnection() as HttpURLConnection)
                                conn.connectTimeout = 3000
                                conn.readTimeout = 3000
                                val code = conn.responseCode
                                val body = conn.inputStream.bufferedReader().use { it.readText() }
                                conn.disconnect()
                                "HTTP $code\n$body"
                            } catch (e: Exception) {
                                "Backend उपलब्ध नहीं है। पहले अपने कंप्यूटर पर FastAPI चलाएँ। (${e.javaClass.simpleName})"
                            }
                            android.os.Handler(mainLooper).post {
                                serverStatus = if (result.startsWith("HTTP 200")) "Backend connected" else "Not connected"
                                serverMessage = result
                                loading = false
                            }
                        }.start()
                    }
                ) { Text(if (loading) "जाँच जारी…" else "Backend connection जाँचें") }

                HorizontalDivider()
                Text("अभी उपलब्ध नहीं", style = MaterialTheme.typography.titleMedium)
                Text("• OTP login और Owner approval — अभी नहीं जुड़े")
                Text("• Delta API balance/orders/positions/chart — अभी नहीं जुड़े")
                Text("• Live trading — जानबूझकर बंद है")
                Text("इस starter में नकली balance, order या profit नहीं दिखाया जाता।")

                HorizontalDivider()
                Text("सुरक्षा", style = MaterialTheme.typography.titleMedium)
                Text("API Secret को ऐप, ZIP या चैट में न डालें। Production में HTTPS, server-side encrypted credentials और असली authentication ज़रूरी हैं।")
            }
        }
    }
}
