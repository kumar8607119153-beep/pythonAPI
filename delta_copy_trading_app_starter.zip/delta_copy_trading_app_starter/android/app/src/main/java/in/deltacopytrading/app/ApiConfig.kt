package in.deltacopytrading.app

object ApiConfig {
    // Android emulator -> local computer's FastAPI.
    // Change for your own development server. Use HTTPS in production.
    const val BASE_URL = "http://10.0.2.2:8000/"
}
